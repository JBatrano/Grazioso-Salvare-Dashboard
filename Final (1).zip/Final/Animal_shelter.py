from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host, port, db, collection):
        # Connection Variables
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = db
        COL = collection

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """ Inserts a document into the collection. Returns True if successful, else False. """
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

    def read(self, query):
        """ Queries for documents from the collection. Returns a list if successful, else an empty list. """
        try:
            result = list(self.collection.find(query))
            return result if result else []
        except Exception as e:
            print(f"An error occurred: {e}")
            return []

    def update(self, query, update_data):
        """ Updates documents in the collection. Returns the count of documents modified. """
        try:
            result = self.collection.update_many(query, update_data)
            return result.modified_count
        except Exception as e:
            print(f"An error occurred during update: {e}")
            return 0

    def delete(self, query):
        """ Deletes documents from the collection. Returns the count of documents deleted. """
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred during delete: {e}")
            return 0

